import Head from 'next/head'
import styles from '../styles/Home.module.css'

export default function Home() {
  return (
    <div className={styles.container}>
      <Head>
        <title>Different Not Disabled Learning</title>
        <meta name="description" content="Learning Might Be Different But That's Okay!" />
      </Head>

      <main className={styles.main}>
        <h1 className={styles.title}>🌟 Different Not Disabled Learning</h1>
        <p className={styles.description}>Learning Might Be Different But That's Okay!</p>
      </main>
    </div>
  )
}
