import Navbar from "../components/Navbar";

export default function Donate() {
  return (
    <div>
      <Navbar />
      <main style={{ padding: "2rem", fontFamily: "sans-serif" }}>
        <h1>Support This Mission ❤️</h1>
        <p>This site is 100% free. Your donations help provide resources for autistic children and families in need.</p>
        <p>One-time or monthly donations welcome.</p>
        <p>Funds may help with therapy support, website upgrades, and small grants for struggling families.</p>
        <p>Contact: <a href="mailto:mishcahhamilton@gmail.com">mishcahhamilton@gmail.com</a></p>
        <div style={{ marginTop: "2rem" }}>
          <a href="https://www.paypal.com/paypalme/mishcahhamilton" target="_blank" rel="noopener noreferrer">
            <button style={{ backgroundColor: "#0070f3", color: "#fff", padding: "1rem 2rem", fontSize: "1.2rem", border: "none", borderRadius: "8px" }}>
              Donate via PayPal
            </button>
          </a>
        </div>
      </main>
    </div>
  );
}
