import Navbar from "../components/Navbar";

export default function Home() {
  return (
    <div>
      <Navbar />
      <main style={{ textAlign: "center", padding: "2rem", fontFamily: "sans-serif" }}>
        <h1>🌟 Different Not Disabled Learning</h1>
        <h2>Learning Might Be Different But That's Okay!</h2>
        <p>Welcome to a free, fun, and inclusive learning platform made in honor of autistic children—especially my son Micah.</p>
        <p>Explore music, ABCs, Bible stories, and more!</p>
        <p>💕 This site is 100% free. You can support us by donating.</p>
        <div style={{ margin: "2rem" }}>
          <img src="/assets/hero-kids.png" alt="Happy Diverse Children" style={{ maxWidth: "100%" }} />
        </div>
        <div>
          <a href="/abc">Start Learning ABC ➡️</a>
        </div>
      </main>
    </div>
  );
}
