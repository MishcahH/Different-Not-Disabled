import Navbar from "../components/Navbar";

export default function ABC() {
  return (
    <div>
      <Navbar />
      <main style={{ padding: "2rem", fontFamily: "sans-serif", textAlign: "center" }}>
        <h1>ABC Learning 🔤</h1>
        <p>Click a letter to hear its sound, see a word, watch the sign, and sing along!</p>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(80px, 1fr))", gap: "1rem" }}>
          {"ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("").map(letter => (
            <div key={letter} style={{ backgroundColor: "#f0f0f0", padding: "1rem", borderRadius: "12px" }}>
              <h2>{letter}</h2>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
