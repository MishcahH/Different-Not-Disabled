import Link from "next/link";

export default function Navbar() {
  return (
    <nav style={{ background: "linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet)", padding: "1rem" }}>
      <ul style={{ display: "flex", justifyContent: "center", gap: "1rem", listStyle: "none", flexWrap: "wrap", fontSize: "1rem" }}>
        <li><Link href="/">Home</Link></li>
        <li><Link href="/abc">ABC Learning</Link></li>
        <li><Link href="/numbers">123 Numbers</Link></li>
        <li><Link href="/colors-shapes">Colors & Shapes</Link></li>
        <li><Link href="/spanish">Spanish Basics</Link></li>
        <li><Link href="/music">Music Time</Link></li>
        <li><Link href="/bible">Bible Stories</Link></li>
        <li><Link href="/avatar">Create Profile</Link></li>
        <li><Link href="/prayer">Prayer Request</Link></li>
        <li><Link href="/donate">Donate</Link></li>
      </ul>
    </nav>
  );
}
